
class BaseTracker:
    def __init__(self):
        pass

    @classmethod
    def call(cls, *args, **kwargs):
        pass
