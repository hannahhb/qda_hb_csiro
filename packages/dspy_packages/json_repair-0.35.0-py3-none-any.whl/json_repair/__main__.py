from .json_repair import cli

if __name__ == "__main__":
    cli()
